import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;

public class BufferMonitor {

    private String fichero;
    private RandomAccessFile buffer;
    private FileLock bloqueo;

    public BufferMonitor(String fichero, boolean borrar) throws IOException {

        this.fichero = fichero;
        try {
            this.buffer = new RandomAccessFile(new File(this.fichero), "rwd");
            if (borrar) {
                this.buffer.setLength(0);
            }
        }catch (FileNotFoundException ex){
            throw new FileNotFoundException("BufferMonitor. Constructor. Error abriendo el archivo: "+fichero);

        }catch (IOException ex){
            throw new IOException("BufferMonitor. Constructor. Error borrando el fichero: "+ fichero);
        }

    }

    public BufferMonitor(String fichero) throws IOException{
        this(fichero, false);
    }

    public boolean escritura(String linea, boolean dejarBloqueado) throws IOException{

        boolean res = false;

        try{

            this.bloqueo = this.buffer.getChannel().lock();
            if(this.buffer.length() ==0){
                this.buffer.seek(0);
                this.buffer.writeUTF(linea);
                res = true;
            }

            if(!dejarBloqueado) this.bloqueo.release();
        }catch (IOException ex){
            throw new IOException("BufferMonitor. escritorio. Error obteniendo el bloqueo del fichero "+this.fichero);

        }
        return res;

    }

    public boolean escritura(String linea) throws IOException {
        return this.escritura(linea, false);
    }

    public String lectura(boolean dejarBloqueado) throws IOException{

        String resultado = null;

        try{

            this.bloqueo = this.buffer.getChannel().lock();
            if(this.buffer.length()!=0){

                this.buffer.seek(0);
                resultado = this.buffer.readUTF()

            }

        }

    }

}

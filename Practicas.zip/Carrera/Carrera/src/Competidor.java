public class Competidor {
}

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ControlCarrera {
    public static void main(String[] args) throws IOException {

        BufferMonitor bufferGanador = new BufferMonitor("/tmp/controlCarrera.txt", true);
        List<Process> listaProcesos = new ArrayList<>();
        System.out.println("Iniciando la carrera");
        listaProcesos.add(Runtime.getRuntime().exec("java Suministrador"));
        for (int i = 0; i < 10; i++) {
            System.out.println("Iniciando competidor "+i );
            listaProcesos.add(Runtime.getRuntime().exec("java Competidor " + 1));
        }
        System.out.println("Esperando al ganador");
        while(!bufferGanador.hayDatos()){
            Thread.sleep(100);
        }
        System.out.println(bufferGanador.lectura(true));
        for (int i = 0; i < listaProcesos.size(); i++) {
            listaProcesos.get(i).destroy();
        }
        bufferGanador.desbloquear();
        bufferGanador.close();






    }
}
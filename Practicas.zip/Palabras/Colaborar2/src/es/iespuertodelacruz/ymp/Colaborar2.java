/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package es.iespuertodelacruz.ymp;

import static es.iespuertodelacruz.ymp.Colaborar2.escribirArchivo;
import static es.iespuertodelacruz.ymp.Colaborar2.generarPalabra;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.Random;

/**
 *
 * @author yared
 */
public class Colaborar2 {

    public static void main(String[] args) {

        int cantidadTotal = 10;
        String filePath = "/tmp/fichero.txt";
        ThreadColaborar tc;
        int num = 0;
        
        while(cantidadTotal <=100){
            
            tc = new ThreadColaborar(filePath, cantidadTotal, num);
            tc.start();
            num +=1;
            cantidadTotal += 10;
            
        }

       

    }

    public static String generarPalabra() {

        Random rnd = new Random();
        String palabra = "";
        int tamanio = rnd.nextInt(10) + 1;

        for (int i = 0; i <= tamanio; i++) {
            palabra += (char) (rnd.nextInt(26) + 97);

        }

        return palabra;

    }

    public static void escribirArchivo(String path, String texto) {

        File archivo = new File(path);

        try ( BufferedWriter bw = Files.newBufferedWriter(archivo.toPath(),
                StandardOpenOption.APPEND,
                StandardOpenOption.CREATE,
                StandardOpenOption.WRITE
        );) {

            bw.write(texto);

        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
    

}

class ThreadColaborar extends Thread {

    private int cantidad;
    private String filePath;
    int num;

    public ThreadColaborar(String filePath, int cantidad, int num) {

        this.num =num;
        this.cantidad = cantidad;
        this.filePath = filePath;

    }

    @Override
    public void run() {
        int j = 0;
        while (j < cantidad) {
            
             String palabras = "";
                palabras += generarPalabra() + "\n";
            escribirArchivo(filePath, palabras);
            j += 1;
            
        }
        System.out.println("Hilo terminado: " + num);

    }


    
    




}

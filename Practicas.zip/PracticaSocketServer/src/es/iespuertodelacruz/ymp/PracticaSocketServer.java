/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.iespuertodelacruz.ymp;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Thread.sleep;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

/**
 *
 * @author Yared
 */
public class PracticaSocketServer {

    
    public static void main(String[] args) throws InterruptedException {
       
        int port = 15070;
        ServerSocket conexion = null;
        Socket canal = null;
        PrintWriter salida = null;
        
        try{
            conexion = new ServerSocket(port);
            System.out.println("Esperando conexión del lector");
            canal = conexion.accept();
            salida = new PrintWriter(canal.getOutputStream());
       
                
            
            Date fecha = new Date();
            salida.print(fecha.toString());
            salida.flush();
            
            salida.close();
            canal.close();
            conexion.close();
            
        }catch(IOException ex){
            System.out.println("Se ha producido un error");
            
        }
        
        
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.iespuertodelacruz.ymp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 *
 * @author Yared
 */
public class PracticaSocketLector {

  
    public static void main(String[] args) {
       
        int port = 15070;
        Socket canal = null;
        BufferedReader entrada = null;
        String lineaEntrada = null;
        try{
            canal = new Socket("localhost", port);
            entrada = new BufferedReader(new InputStreamReader(canal.getInputStream()));
            while((lineaEntrada = entrada.readLine())!=null){
                System.out.println(lineaEntrada);
            }
        }catch(IOException ex){
            System.out.println(ex);
        }
        
        
    }
    
}

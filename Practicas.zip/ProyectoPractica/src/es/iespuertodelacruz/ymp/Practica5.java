/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.iespuertodelacruz.ymp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Yared
 */
public class Practica5 {
    
    public static void main(String[] args) {
        
        List<Integer> lista1 = Arrays.asList(2, 8, 9, 11);
        List<Integer> lista2 = Arrays.asList(3, 5, 7, 9, 11, 13, 15, 18);
        
        System.out.println(mezcla(lista1, lista2));
        
    }
    
    public static List<Integer> mezcla( List<Integer> lista1, List<Integer> lista2){ 
    
        List<Integer> resultado = new ArrayList<Integer>();
        int i, j;
        
        for (i = 0, j = 0; i < lista1.size() && j < lista2.size();) {
            
            if ( lista1.get(i)<lista2.get(j)){
                resultado.add(lista1.get(i));
                i++;
            }else{
                resultado.add(lista2.get(j));
                j++;
            }
        
        }
        
        while ( i < lista1.size()){
            resultado.add(lista1.get(i));
            i++;
        }
        while ( j < lista2.size()){
            resultado.add(lista2.get(j));
            j++;
        }
        
        return resultado;
        
    }
}

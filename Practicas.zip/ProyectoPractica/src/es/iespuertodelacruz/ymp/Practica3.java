/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.iespuertodelacruz.ymp;

import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Yared
 */
public class Practica3 {

    public static void _main(String[] args) {

        Pattern p = Pattern.compile("^[a-zA-Z0-9,;.:_*@#$%&()]+$");
        Matcher m = null;
        Random rnd = new Random();

        int longitud = 20; //Integer.parseInt(args[0]);

        ArrayList<String> password = new ArrayList<String>();

        while (password.size() < longitud) {

            int random = rnd.nextInt(127);
            char letra = (char) random;
            m = p.matcher(letra + "");

            if (m.matches()) {
                password.add(letra + "");
            }
        }

        for (String string : password) {
            System.out.print(string);
        }
        System.out.println("");

    }
    
    
    public static String rango(char inicio, char fin){
        
        String resultado="";
        for(char c = inicio; c <= fin; c++){
            resultado += c;
        }
        return resultado;
        
    }
    
    
    // [a-zA-Z0-9,;.:-_*@#$%&()[]]
    public static void main(String[] args) {
        
        int longitud = Integer.parseInt(args[0]);
       
        Random rnd = new Random();
        
        String contrasenia="";
        
        String alfabeto=rango('a', 'z');
        alfabeto+=rango('A','Z');
        alfabeto+=rango('0', '9');
        alfabeto+=",;.:-_*@#$%&()[]";
        
        for (int i = 0; i < longitud; i++) {
            contrasenia+=alfabeto.charAt(rnd.nextInt(alfabeto.length()));
        }
        
        System.out.println(contrasenia);
        
               
        
        
    }

}

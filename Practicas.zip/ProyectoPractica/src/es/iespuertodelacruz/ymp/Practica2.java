/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.iespuertodelacruz.ymp;

import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author Yared
 */
public class Practica2 {
    
    public static void main(String[] args) {
        
        Set<Integer> numerosPrimitiva = new TreeSet<Integer>();
        Random rnd = new Random();
        
        while ( numerosPrimitiva.size() < 6){
            
           numerosPrimitiva.add(rnd.nextInt(49)+1);
            
        }
        
        for (Integer integer : numerosPrimitiva) {
            System.out.print(integer + ", ");
        }
        System.out.println("\b\b");
        
        
    }
    
}

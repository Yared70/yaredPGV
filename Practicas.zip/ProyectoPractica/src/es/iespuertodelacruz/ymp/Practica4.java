/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package es.iespuertodelacruz.ymp;

/**
 *
 * @author yared
 */
public class Practica4 {

    public static void main(String[] args) {
        
        int numero = 36; //Integer.parseInt(args[0]);
        int primo = 2;
        System.out.print("\n" + numero + ": ");
        
        while (numero % 2 == 0){
            System.out.print(primo + "x");
            numero/=2;
        }
        primo = 3;
        while(numero > 1){
            
            while( numero%primo == 0 ){
                
                System.out.print(primo + "x");
                numero /= primo;
                
            }
            primo += 2;
            
            
        }
        System.out.print("\b\n");
        
        
    }
    
}

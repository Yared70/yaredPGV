/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package es.iespuertodelacruz.ymp;

/**
 *
 * @author Yared
 */
public class ProyectoPractica {


    public static void main(String[] args) {
       
        int sumaTotal = 0;
        
        int numero1 = Integer.parseInt(args[0]);
        int numero2 = Integer.parseInt(args[1]);
        
        for (int i = numero1; i <= numero2; i++) {
            sumaTotal += i;
        }
        
        System.out.println(sumaTotal);
        System.out.println(sumaTotal/(double)(numero2-numero1+1));
        
        
    }
    
}
